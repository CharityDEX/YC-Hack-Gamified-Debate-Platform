// Follow this setup guide to integrate the Deno language server with your editor:
// https://deno.land/manual/getting_started/setup_your_environment
// This enables autocomplete, go to definition, etc.

// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts"

import OpenAI from 'https://deno.land/x/openai@v4.24.0/mod.ts'
import { createClient } from 'jsr:@supabase/supabase-js@2'

async function getClaimVerdicts(query: string, key: string) {
    const apiUrl = `https://factchecktools.googleapis.com/v1alpha1/claims:search?query=${encodeURIComponent(query)}&key=${key}`;

    try {
        const response = await fetch(apiUrl);

        // Check if response is successful
        if (!response.ok) {
            console.error("DID NOT WORK");
            throw new Error(`Google Fact Check API returned an error: ${response.statusText}`);
        }

        const { claims } = await response.json();

        if (claims) {
            // Transform the data to extract claim and verdict pairs
            const formattedClaims = claims.map((claimData: any) => {
                const claimText = claimData.text;
                const verdict = claimData.claimReview[0]?.textualRating || "No Verdict Available";
    
                return `Claim: ${claimText}\nVerdict: ${verdict}`;
            });

            return formattedClaims.join('\n\n');
            
        } else {
            return 'Sorry, no verifiable claims were found. Please use personal knowledge.';
        }
    } catch (error) {
        return { message: 'Error fetching fact checks', error: error.message };
    }
}

Deno.serve(async (req) => {

    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    const openai = new OpenAI({
        apiKey: openaiApiKey,
    })

    const googleApiKey = Deno.env.get('GOOGLE_API_KEY');
    const claim = "thomas edison did not invent the lightbulb";
    const verdicts = await getClaimVerdicts(claim, googleApiKey);
    console.error(`Verdicts! ${verdicts}`);

    const systemMessage = {
        role: 'system',
        content: `You are a fact-checking claim evaluation assistant. You will be provided with a users claim, and a lot of claim verdict pairs from google fact check api on a similar topic. Using the credible verdicts from these pairs, please make an estimation whether or not the users claim is true or false. Please output only one number showing your answer. Please do not use your general knowledge, unless there are no online claims found. Output 0 if the claim is false, 1 if it is true, and 3 if you are unsure or do not have enough information to judge. Here is the claim you should fact check: ${claim} \n Here are the online claims and verdicts: ${verdicts} \n Your evaluation:`
    };

    const chatCompletion = await openai.chat.completions.create({
        messages: [systemMessage],
        // Choose model from here: https://platform.openai.com/docs/models
        model: 'gpt-4o-mini',
        stream: false
    })

    const reply = chatCompletion.choices[0].message.content
    console.error(`REPLY! ${reply}`)

    const contentType = req.headers.get('Content-Type') || '';
    if (!contentType.includes('multipart/form-data')) {
        return new Response('Invalid content type. Expected multipart/form-data.', { status: 400 });
    }

    const formData = await req.formData();
    const audio = formData.get('audio');
    const user_id = formData.get('user_id');
    const message_role = formData.get('message_role');

    if (!audio || !(audio instanceof File)) {
        return new Response('Audio file not provided', { status: 400 });
    }

    // Transcribe the audio using OpenAI Whisper
    const transcriptionResponse = await openai.audio.transcriptions.create({
        file: audio,
        model: "whisper-1",
        language: "en"
    });

    const message_content = transcriptionResponse.text;

    // google fact check here
    const fact_check = true;

    // write to table
    const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    )
    const { data, error } = await supabaseClient.from('messages').insert([{ user_id, message_role, message_content, fact_check }])
    //const { data, error } = await supabaseClient.from('users').insert([{ user_id, first_name, last_name } ])
    //const { data, error } = await supabaseClient.from('users').insert([{ user_id, first_name, last_name } ])

    const response_data = { "fact_check": reply }

    return new Response(
        JSON.stringify(response_data),
        { headers: { "Content-Type": "application/json" } },
    )
})

/* To invoke locally:

  1. Run `supabase start` (see: https://supabase.com/docs/reference/cli/supabase-start)
  2. Make an HTTP request:

  curl -i --location --request POST 'http://127.0.0.1:54321/functions/v1/argument-update' \
    --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0' \
    --header 'Content-Type: application/json' \
    --data '{"name":"Functions"}'

*/
